﻿using System;
using System.IO;
using System.Net.Http;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Collections.ObjectModel;
using Microsoft.Win32; 

namespace FileDownloaderApp
{
    public partial class MainWindow : Window
    {
        private string saveLocation;
        private HttpClient client;
        private CancellationTokenSource cancellationTokenSource;

        public ObservableCollection<DownloadItem> DownloadItems { get; set; }

        public MainWindow()
        {
            InitializeComponent();
            client = new HttpClient();
            DownloadItems = new ObservableCollection<DownloadItem>();
            DownloadListView.ItemsSource = DownloadItems;
        }

        private void ChooseSaveLocationButton_Click(object sender, RoutedEventArgs e)
        {
            var dialog = new OpenFileDialog();
            dialog.CheckFileExists = false;
            dialog.ValidateNames = false;
            dialog.FileName = "Folder Selection.";

            if (dialog.ShowDialog() == true)
            {
                saveLocation = Path.GetDirectoryName(dialog.FileName);
            }
        }

        private async void DownloadButton_Click(object sender, RoutedEventArgs e)
        {
            string url = UrlTextBox.Text;
            if (string.IsNullOrEmpty(url) || string.IsNullOrEmpty(saveLocation))
            {
                MessageBox.Show("Please provide both URL and save location.");
                return;
            }

            try
            {
                DownloadButton.IsEnabled = false;
                CancelButton.IsEnabled = true;

                cancellationTokenSource = new CancellationTokenSource();
                var token = cancellationTokenSource.Token;

                var downloadItem = new DownloadItem
                {
                    FileName = Path.GetFileName(url),
                    Progress = 0,
                    Status = "Downloading..."
                };
                DownloadItems.Add(downloadItem);

                await DownloadFileAsync(url, saveLocation, token, downloadItem);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error: {ex.Message}");
            }
            finally
            {
                DownloadButton.IsEnabled = true;
                CancelButton.IsEnabled = false;
            }
        }

        private async Task DownloadFileAsync(string url, string savePath, CancellationToken token, DownloadItem downloadItem)
        {
            using (var response = await client.GetAsync(url, HttpCompletionOption.ResponseHeadersRead, token))
            {
                if (!response.IsSuccessStatusCode)
                {
                    MessageBox.Show("Failed to download file.");
                    return;
                }

                var totalBytes = response.Content.Headers.ContentLength ?? 0;
                var filePath = Path.Combine(savePath, downloadItem.FileName);
                var buffer = new byte[8192];

                using (var fileStream = new FileStream(filePath, FileMode.Create, FileAccess.Write, FileShare.None))
                using (var stream = await response.Content.ReadAsStreamAsync())
                {
                    long totalRead = 0;
                    int bytesRead;

                    while ((bytesRead = await stream.ReadAsync(buffer, 0, buffer.Length)) > 0)
                    {
                        token.ThrowIfCancellationRequested();
                        await fileStream.WriteAsync(buffer, 0, bytesRead);
                        totalRead += bytesRead;

                        double progress = (double)totalRead / totalBytes * 100;
                        downloadItem.Progress = progress;
                        downloadItem.Status = $"Downloading {progress:F2}%";
                    }
                }

                downloadItem.Status = "Completed";
                MessageBox.Show("Download completed!");
            }
        }

        private void CancelButton_Click(object sender, RoutedEventArgs e)
        {
            cancellationTokenSource?.Cancel();
            MessageBox.Show("Download canceled.");
            DownloadButton.IsEnabled = true;
            CancelButton.IsEnabled = false;
        }
    }

    public class DownloadItem
    {
        public string FileName { get; set; }
        public double Progress { get; set; }
        public string Status { get; set; }
    }
}
